module alu (
    input  logic        clk,
    input  logic        start,
    input  logic [63:0] line_data,
    output logic [8:0]  X,
    output logic [7:0]  Y,
    output logic [6:0]  Z,
    output logic [4:0]  U, V,
    output logic        done
);
assign Y = line_data[59:52];
    // === ������� ===
    logic [4:0] u_start = line_data[51:47];
    logic [4:0] u_end   = line_data[46:42];
    logic [4:0] v_start = line_data[41:37];
    logic [4:0] v_end   = line_data[36:32];

    logic [8:0] x_start = line_data[31:23];
    logic [8:0] x_end   = line_data[22:14];
    logic [6:0] z_start = line_data[13:7];
    logic [6:0] z_end   = line_data[6:0];

    logic [15:0] du_fixed, dv_fixed;
    logic [15:0] dz_fixed;
    logic [8:0] span;

    assign span = (x_end > x_start) ? (x_end - x_start) : 9'd1;

    assign du_fixed = ((u_end - u_start) << 8) / span;
    assign dv_fixed = ((v_end - v_start) << 8) / span;
    assign dz_fixed = ((z_end - z_start) << 8) / span;

    // === ��ǰ��ֵ״̬�����㣩 ===
    logic [15:0] u_curr, v_curr, z_curr;
    logic [8:0]  x_curr;

    always_ff @(posedge clk) begin
        if (start) begin
            x_curr <= x_start;
            u_curr <= u_start<<8;
            v_curr <= v_start<<8;
            z_curr <= z_start<<8;
//            du = (u_end - u_start)/span;
//            dv = (v_end - v_start)/span;
//            dz = (z_end - z_start)/span;
            
            done   <= 0;
        end else if (!done) begin
            X <= x_curr;
            U <= u_curr[12:8];  // �� 5 λ��Ϊ�������꣨�൱�ڳ� 32��
            V <= v_curr[12:8];
            Z <= z_curr[14:8];   // �� 7 λ���ֵ��ӳ�� 0~127��

            if (x_curr == x_end) begin
                done <= 1;
            end else begin
                x_curr <= x_curr + 1;
                u_curr <= u_curr + du_fixed;
                v_curr <= v_curr + dv_fixed;
                z_curr <= z_curr + dz_fixed;
            end
        end
    end
endmodule

module z_compare_unit (
    input  logic clk,
    input  logic [6:0] z_buf_in,   // ������ z ֵ��Z-buffer��
    input  logic [6:0] z_in,       // ��ǰ���� z ֵ

    output logic       wea
);

always_ff@(posedge clk) begin
    if (z_in < z_buf_in) begin
        wea          <= 1'b1;
    end else begin
        wea          <= 1'b0;
    end
end

endmodule