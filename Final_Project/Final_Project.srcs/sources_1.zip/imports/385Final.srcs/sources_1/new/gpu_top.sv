`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2025/04/17 19:22:58
// Design Name: 
// Module Name: gpu_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module gpu_top(
    input logic clk, rst,// continue_i,frame_done,

    output logic hdmi_clk_n,
    output logic hdmi_clk_p,
    output logic [2:0] hdmi_tx_n,
    output logic [2:0] hdmi_tx_p,
    
    //HEX displays
    output logic [7:0] hex_segA,
    output logic [3:0] hex_gridA,
    output logic [7:0] hex_segB,
    output logic [3:0] hex_gridB,
    
    input logic uart_rtl_0_rxd,
    output logic uart_rtl_0_txd,
    input logic usb_spi_miso,
    output logic usb_spi_mosi,
    output logic usb_spi_sclk,
    output logic [0:0]usb_spi_ss
    );
//logic
logic clk_25MHz, clk_125MHz, clk_50MHz,clk_150MHz, locked;
logic hsync, vsync, vde;
logic[7:0] red, green, blue;
logic [9:0] drawX, drawY;
logic [17:0] addra,addrb;
logic [16:0] addrz,addrzr;
logic [3:0] texture_buffer;
logic [3:0] dina;
logic [3:0] buf_plt;
//logic enable;
logic run;

//logic frame_done;
logic [6:0] Z,z_buf_r;
logic [8:0] X;
logic [7:0] Y;
logic [4:0] U,V;
logic [3:0] MinZ;
logic wea, czena, clear_fb;

logic [63:0] line_data;


  mb_lab7_1 mb_lab7_1_i
       (.clk_100MHz(clk),
        .clk_25MHz(clk_25MHz),
        .clk_125MHz(clk_125MHz),
        .clk_50MHz(clk_50MHz),
        .clk_150MHz(clk_150MHz),
        .locked(locked),
        .gpu_ready(gpu_ready),
        .line_data(line_data),
        .reset_rtl_0(~rst),
        .uart_rtl_0_rxd(uart_rtl_0_rxd),
        .uart_rtl_0_txd(uart_rtl_0_txd),
        .usb_spi_miso(usb_spi_miso),
        .usb_spi_mosi(usb_spi_mosi),
        .usb_spi_sclk(usb_spi_sclk),
        .usb_spi_ss(usb_spi_ss));

//����洢����ʱʹ��rom
//logic [31:0] data_reg [8];
//initial begin
//    data_reg[0] = {4'd0,8'd70,10'd15,10'd15};
//    data_reg[1] = {9'd73,9'd160,7'd64,7'd64};
//end

//�źŲ��
assign frame_done = line_data[61];
assign run = line_data[60];
//alu
alu alu_0(
    .clk(clk_50MHz),
    .start(run),
    .line_data(line_data),
    .X(X),
    .Y(Y),
    .Z(Z),
    .U(U),
    .V(V),
    .done(gpu_ready)
);


//buffer�л��߼�
addr_controller addrc (
    .frame_done(frame_done),
    .clk(clk_50MHz),
    .rst(rst),
    .clk_150MHz(clk_150MHz),
    .drawX(drawX),
    .drawY(drawY),
    .pixelX(X),
    .pixelY(Y),
    .addra(addra),
    .addrb(addrb),
    .addrz(addrz),
    .addrzr(addrzr),
    .czena(czena),
    .clear_fb(clear_fb)
);

//z buffer
//compare z logic�Ա����ڵ�zֵ�ʹ洢��zֵ�������С��д��zbuffer
z_compare_unit zcomp(
    .clk(clk_50MHz),
    .z_buf_in(z_buf_r),
    .z_in(Z),
    .wea(wea)
);
//���zbuffer


blk_mem_gen_1 zbuffer (
    .clka(clk_150MHz),
    .wea(wea),//�Ƚϴ�С֮��д��
    .addra(addrz),
    .dina(Z),
    .douta(z_buf_r),
    .clkb(clk_150MHz),
    .web(czena),
    .addrb(addrzr),
    .dinb(7'b1111111),
    .doutb()
    );

texture_rom texture(
    .U(U),
    .V(V),
    .out(texture_buffer)
    );

assign dina = !clear_fb ? texture_buffer: 4'b0;
//frame buffer
blk_mem_gen_0 framebuffer (
    .clka(clk_150MHz),
    .wea(wea || clear_fb),
    .addra(addra),
    .dina(dina),
//    .douta(),
    .web(1'b0),
    .addrb(addrb),
    .dinb(32'h0000),
    .doutb(buf_plt)
    );

//pallet
palette_rom palette(
    .palette(buf_plt),
    .red(red),
    .green(green),
    .blue(blue)
);

//clk wiz
//    clk_wiz_0 clk_wiz (
//        .clk_out1(clk_25MHz),
//        .clk_out2(clk_125MHz),
//        .clk_out3(clk_50MHz),
//        .reset(rst),
//        .locked(locked),
//        .CLK_in1(clk)
//    );
    
    
//vga controller
    vga_controller vga (
        .pixel_clk(clk_25MHz),
        .reset(rst),
        .hs(hsync),
        .vs(vsync),
        .active_nblank(vde),
        .drawX(drawX),
        .drawY(drawY)
    );

//Real Digital VGA to HDMI converter
    hdmi_tx_0 vga_to_hdmi (
        //Clocking and Reset
        .pix_clk(clk_25MHz),
        .pix_clkx5(clk_125MHz),
        .pix_clk_locked(locked),
        //Reset is active LOW
        .rst(rst),
        //Color and Sync Signals
        .red(red),
        .green(green),
        .blue(blue),
        .hsync(hsync),
        .vsync(vsync),
        .vde(vde),
        
        //aux Data (unused)
        .aux0_din(4'b0),
        .aux1_din(4'b0),
        .aux2_din(4'b0),
        .ade(1'b0),
        
        //Differential outputs
        .TMDS_CLK_P(hdmi_clk_p),          
        .TMDS_CLK_N(hdmi_clk_n),          
        .TMDS_DATA_P(hdmi_tx_p),         
        .TMDS_DATA_N(hdmi_tx_n)          
    );
    
    hex_driver HexA (
        .clk(clk),
        .reset(rst),
        .in({line_data[63:60], line_data[59:56], line_data[23:20], line_data[19:16]}),
        .hex_seg(hex_segA),
        .hex_grid(hex_gridA)
    );
    
    hex_driver HexB (
        .clk(clk),
        .reset(rst),
        .in({line_data[15:12], line_data[11:8], line_data[7:4], line_data[3:0]}),
        .hex_seg(hex_segB),
        .hex_grid(hex_gridB)
    );
endmodule
