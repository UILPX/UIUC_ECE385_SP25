#include "gpu_axi_lite.h"
#include "xil_io.h"
#include <unistd.h>

void gpu_init(void) { /* nothing yet */ }

void gpu_wait_ready(void){
	while ( (Xil_In32(GPU_DATA_CTRL) & (GPU_CTL_DONE_MASK)) == 0 ){
		xil_printf("Waiting...");
	};
}
//{
//    u32 reg_val;             // 32-bit �޷���
//
//    do {
//        reg_val = Xil_In32(GPU_DATA_CTRL);               // ���Ĵ���
//        //xil_printf("GPU_DATA_CTRL = 0x%08lx\r\n", reg_val);
//        //usleep(1000);
//        /* ��ѡ����һ�����ʱ�������ӡ����ˢ��
//           usleep(1000);   // 1 ms���� #include "sleep.h"
//        */
//    } while ( (reg_val & (GPU_CTL_DONE_MASK)) == 0 );
//}

void gpu_send_scanline(uint32_t lo, uint32_t hi_data)
{
    gpu_wait_ready();                                   /* GPU idle      */
    Xil_Out32(GPU_DATA_HI, hi_data);                         /* data bits 31:0*/
    //xil_printf("%x",hi_data);
    Xil_Out32(GPU_DATA_LO, lo);                         /* data+RUN      */
    Xil_Out32(GPU_DATA_CTRL,GPU_CTL_RUN);
    //xil_printf("%x\r\n",LO);
    //usleep(5000);
}

void gpu_frame_done(void)
{
    gpu_wait_ready();
    Xil_Out32(GPU_DATA_CTRL, GPU_CTL_FRAME_DONE);
    xil_printf("------------------------------------------------------------\r\n");
}
