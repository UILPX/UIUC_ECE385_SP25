/*  rasteriser.c  (unchanged logic, reposted for download)
 *
 *  Simple software rasteriser that converts one cube triangle
 *  into horizontal scan lines and streams them to the GPU through
 *  scanline_out().
 *
 *  Public entry: void rasterise_triangle(int tri_index);
 */

#include <stdint.h>
#include <math.h>
#include "rasteriser.h"
#include <stdbool.h>
//#include <stdio.h>

extern ivec2   screen_pts[8];
extern uint8_t depth[8];
extern void scanline_out(uint8_t y,
                         uint16_t x0, uint16_t x1,
                         uint8_t  u0, uint8_t  u1,
                         uint8_t  v0, uint8_t  v1,
                         uint8_t  z0, uint8_t  z1);

typedef struct {
    uint8_t v[3];
    uint8_t u[3];
    uint8_t vtex[3];
} TriDef;

/* cube triangles with UVs


static const TriDef g_tris[12] = {
{{4,7,5}, {31,31,0}, {31,0,31}}, {{5,7,6}, {0,31,0}, {31,0,0}},
{{0,1,3}, {0,31,0}, {31,31,0}}, {{1,2,3}, {31,31,0}, {31,0,0}},
{{0,7,4}, {31,0,0}, {31,0,31}}, {{0,3,7}, {31,31,0}, {31,0,0}},
{{5,2,1}, {31,0,0}, {31,0,31}}, {{5,6,2}, {31,31,0}, {31,0,0}},
{{3,2,7}, {0,31,0}, {31,31,0}}, {{2,6,7}, {31,31,0}, {31,0,0}},
{{0,4,1}, {0,0,31}, {0,31,0}}, {{1,4,5}, {31,0,31}, {0,31,31}}
};
*/
///*
static const TriDef g_tris[12] = {
{{4,5,7},{31,0,31},{31, 31,0}}, {{5,6,7},{0,0, 31},{31,0,0}},
{{0,3,1},{0,0,31},{31, 0,31}}, {{1,3,2},{31,0, 31},{31,0,0}},
{{0,4,7},{31,0,0},{31, 31,0}}, {{0,7,3},{31,0, 31},{31,0, 0}},
{{5,1,2},{31,0,0},{31, 31,0}}, {{5,2,6},{31,0, 31},{31,0, 0}},
{{3,7,2},{0,0,31},{31, 0,31}}, {{2,7,6},{31,0,31},{31,0,0}},
{{0,1,4},{0,31,0},{0, 0,31}}, {{1,5,4},{31,31, 0},{0,31,31}}
};
//*/
/*
static const TriDef g_tris[4] = {
{{0,1,2},{0,15,31},{0, 31,0}}, {{0,2,3},{0,15, 31},{0,31,0}},
{{0,1,3},{0,15,31},{0, 31,0}}, {{1,2,3},{0,15, 31},{0,31,0}},

};
*/

static inline int clamp(int v,int lo,int hi){
    return (v<lo)?lo:(v>hi)?hi:v;
}

static void emit_span(int y,
                      float xL,float xR,
                      float uL,float uR,
                      float vL,float vR,
                      float zL,float zR)
{
	if (xL > xR) {
	    float t;
	    t = xL; xL = xR; xR = t;
	    t = uL; uL = uR; uR = t;
	    t = vL; vL = vR; vR = t;
	    t = zL; zL = zR; zR = t;
	}

	    // ��ת��������������
	    int xi0 = (int)(xL + 0.5f);
	    int xi1 = (int)(xR + 0.5f);

	if ((xi1 < 0 && xi0 < 0) || (xi1 > 319 && xi0 > 319)) return;

    /* **�ڲü���** �����ֵϵ�� */
    int xi0_clamped = clamp(xi0, 0, 319);
    int xi1_clamped = clamp(xi1, 0, 319);

    float denom = (xR - xL) + 1e-5f;
    float t0 = ((xi0_clamped) - xL) / denom;
    float t1 = ((xi1_clamped) - xL) / denom;
    //printf("y%d xl%f xr%f\r",y,(double)xL,(double)xR);
    scanline_out((uint8_t)y,
                 (uint16_t)xi0_clamped,(uint16_t)xi1_clamped,
                 (uint8_t)clamp((int)(uL+t0*(uR-uL)+0.5f),0,31),
                 (uint8_t)clamp((int)(uL+t1*(uR-uL)+0.5f),0,31),
                 (uint8_t)clamp((int)(vL+t0*(vR-vL)+0.5f),0,31),
                 (uint8_t)clamp((int)(vL+t1*(vR-vL)+0.5f),0,31),
                 (uint8_t)clamp((int)(zL+t0*(zR-zL)+0.5f),0,127),
                 (uint8_t)clamp((int)(zL+t1*(zR-zL)+0.5f),0,127));
}

void rasterise_triangle(int tix)
{
    const TriDef *T=&g_tris[tix];

    struct {int x,y; int u,v,z;} V[3],tmp;
    for(int i=0;i<3;i++){
        int vi=T->v[i];
        V[i].x=screen_pts[vi].x;
        V[i].y=screen_pts[vi].y;
        V[i].u=T->u[i];
        V[i].v=T->vtex[i];
        V[i].z=depth[vi];
    }


    for (int i = 0; i < 3; ++i)
        for (int j = i + 1; j < 3; ++j)
            if (V[i].y > V[j].y) {
                tmp = V[i];   /* ����Ľṹ���� */
                V[i]     = V[j];
                V[j]     = tmp;
            }

    int y0=V[0].y, y1=V[1].y, y2=V[2].y; if(y0==y2) return;
    float dy02=(float)(y2-y0), dx02=(float)(V[2].x-V[0].x)/dy02,
          du02=(float)(V[2].u-V[0].u)/dy02, dv02=(float)(V[2].v-V[0].v)/dy02,
          dz02=(float)(V[2].z-V[0].z)/dy02;

    float dy01=(float)(y1-y0), dx01=dy01? (float)(V[1].x-V[0].x)/dy01:0.f,
          du01=dy01? (float)(V[1].u-V[0].u)/dy01:0.f,
          dv01=dy01? (float)(V[1].v-V[0].v)/dy01:0.f,
          dz01=dy01? (float)(V[1].z-V[0].z)/dy01:0.f;

    float dy12=(float)(y2-y1), dx12=dy12? (float)(V[2].x-V[1].x)/dy12:0.f,
          du12=dy12? (float)(V[2].u-V[1].u)/dy12:0.f,
          dv12=dy12? (float)(V[2].v-V[1].v)/dy12:0.f,
          dz12=dy12? (float)(V[2].z-V[1].z)/dy12:0.f;

    float xL=V[0].x,uL=V[0].u,vL=V[0].v,zL=V[0].z;
    float xR=xL,uR=uL,vR=vL,zR=zL;


    int y0i = (int)ceilf((float)y0);   /* ���� v0 ����ɨ����   */
    int y1i = (int)ceilf((float)y1);   /* �е� v1 ����ɨ����   */
    int y2i = (int)ceilf((float)y2);   /* �׵� v2 ����ɨ����   */

    int y;             /* C89 ���ݡ�����ǰ����ѭ������ */

	for (y = y0i; y < y1i; ++y) {
		//xil_printf("%d,",y);
		if (y >= 0 && y < 240 && xL != xR)
			emit_span(y, xL, xR, uL, uR, vL, vR, zL, zR);

		/* ����� v0-v2  */
		xL += dx02;  uL += du02;  vL += dv02;  zL += dz02;
		/* �ұ��� v0-v1  */
		xR += dx01;  uR += du01;  vR += dv01;  zR += dz01;
	}
		//xil_printf("\r\n");

		/* ---- ���ұ߱��л��� v1-v2������װ룩 ---- */
	xR  = (float)V[1].x;   uR = (float)V[1].u;
	vR  = (float)V[1].v;   zR = (float)V[1].z;

		/* ---------- �װ����ǣ�v1 �� v2 ---------- */
	for (y = y1i; y < y2i; ++y) {
		//if (y >= 0 && y < 240)
			emit_span(y, xL, xR, uL, uR, vL, vR, zL, zR);
		/* ������� v0-v2 */
		xL += dx02;  uL += du02;  vL += dv02;  zL += dz02;
		/* �ұ��� v1-v2 */
		xR += dx12;  uR += du12;  vR += dv12;  zR += dz12;
	}
}
