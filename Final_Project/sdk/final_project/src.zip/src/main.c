/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

/*
 * cube_renderer.c
 * Stand alone minimal demo for a single cube with
 * AXI Lite scan line streaming and SPI keyboard control.
 *
 * Requires:
 *   - gpu_axi_lite.h  (handshake helpers)
 *   - keyboard_spi.h  (kb_spi_poll_char())
 *   - math helpers: vec3, mat3, mat3_rotate_xyz(), mat3_mul_vec3()
 *   - rasteriser functions: rasterise_triangle()
 *
 * Author: ChatGPT ?C 2025 04 30
 */

#include <stdint.h>
#include "platform.h"
#include "lw_usb/GenericMacros.h"
#include "lw_usb/GenericTypeDefs.h"
#include "lw_usb/MAX3421E.h"
#include "lw_usb/USB.h"
#include "lw_usb/usb_ch9.h"
#include "lw_usb/transfer.h"
#include "lw_usb/HID.h"
#include "xil_printf.h"
#include <math.h>
#include "gpu_axi_lite.h"
#include "rasteriser.h"
#include "stats.h"
#include <xtmrctr.h>
extern XTmrCtr Usb_timer;
//#include <stdio.h>
//#include <unistd.h>

ivec2   screen_pts[8];
uint8_t depth[8];

/* ---------- basic vector / matrix stubs (replace with your own) ---------- */
typedef struct { float x, y, z; } vec3;
typedef struct { float m[3][3]; } mat3;

static inline vec3 mat3_mul_vec3(mat3 R, vec3 v) {
    vec3 o;
    o.x = R.m[0][0]*v.x + R.m[0][1]*v.y + R.m[0][2]*v.z;
    o.y = R.m[1][0]*v.x + R.m[1][1]*v.y + R.m[1][2]*v.z;
    o.z = R.m[2][0]*v.x + R.m[2][1]*v.y + R.m[2][2]*v.z;
    return o;
}

static mat3 mat3_rotate_xyz(float rx, float ry, float rz)
{
    float sx = sinf(rx), cx = cosf(rx);
    float sy = sinf(ry), cy = cosf(ry);
    float sz = sinf(rz), cz = cosf(rz);

    mat3 Rz = {{{ cz,-sz, 0},{ sz, cz,0},{0,0,1}}};
    mat3 Ry = {{{ cy, 0, sy},{ 0,1,0},{-sy,0,cy}}};
    mat3 Rx = {{{1,0,0},{0,cx,-sx},{0,sx,cx}}};

    mat3 T1, T2;
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++){
            T1.m[i][j]=0;
            for(int k=0;k<3;k++) T1.m[i][j]+=Rz.m[i][k]*Ry.m[k][j];
        }
    for(int i=0;i<3;i++)
        for(int j=0;j<3;j++){
            T2.m[i][j]=0;
            for(int k=0;k<3;k++) T2.m[i][j]+=T1.m[i][k]*Rx.m[k][j];
        }
    return T2;
}
/* ---------- user supplied rasteriser ------------------------------------ */
extern void rasterise_triangle(int tri_index);
/* global arrays used by rasteriser (screen_pts[], depth[]) must be declared */
//static ivec2 screen_pts[8];
//static uint8_t depth[8];

/* ---------- cube model --------------------------------------------------- */
///*
static const vec3 g_model[8] = {
    {-0.5f,-0.5f,-0.5f}, {+0.5f,-0.5f,-0.5f},
    {+0.5f,+0.5f,-0.5f}, {-0.5f,+0.5f,-0.5f},
    {-0.5f,-0.5f,+0.5f}, {+0.5f,-0.5f,+0.5f},
    {+0.5f,+0.5f,+0.5f}, {-0.5f,+0.5f,+0.5f}
};
//*/
/*
static const vec3 g_model[4] = {
    {0.f,-0.5f,0.f}, {-0.5f,0,-0.5f},
    {0.5f,0.f,-0.5f}, {0.f,0.f,0.5f}
};
*/
static vec3 g_world[8];

/* ---------- console debug ----------------------------------------------- */
//static void print_vertices(void)
//{
//
//    for(int i=0;i<8;i++)
//        printf(" %d(%.2f,%.2f,%.2f)\r",i,g_world[i].x,g_world[i].y,g_world[i].z);
//}


/* ---------- keyboard handler -------------------------------------------- */
#define DEG_STEP 0.05f
static void handle_usb_keyboard(const BOOT_KBD_REPORT *rep,
                                float *rx, float *ry, float *rz)
{
    /* HID usage IDs for letters (see USB HID Usage Tables)      */
    enum { KEY_A = 0x04, KEY_D = 0x07, KEY_E = 0x08, KEY_Q = 0x14,
           KEY_S = 0x16, KEY_W = 0x1A };

    for (int i = 0; i < 6; ++i) {
        switch (rep->keycode[i]) {
        case KEY_W: *rx -= DEG_STEP; break;
        case KEY_S: *rx += DEG_STEP; break;
        case KEY_A: *ry -= DEG_STEP; break;
        case KEY_D: *ry += DEG_STEP; break;
        case KEY_Q: *rz -= DEG_STEP; break;
        case KEY_E: *rz += DEG_STEP; break;
        default:    break;
        }
    }
}

/* ---------- send one scanline via AXI Lite ------------------------------ */
static inline void push_scanline(
        uint8_t y,
        uint16_t x0,uint16_t x1,
        uint8_t u0,uint8_t u1,
        uint8_t v0,uint8_t v1,
        uint8_t z0,uint8_t z1)
{
    /* pack lower 32 bits exactly as before */
    uint32_t lo =
        (y  <<20) | (u0<<15) | (u1<<10) |
        (v0 <<5)  |  v1;

    /* pack upper 28 data bits (leave ctrl nibble clear) */
    uint32_t hi_data =
        (x0 <<23) | (x1<<14) | (z0<<7) | z1;

    gpu_send_scanline(lo, hi_data);   /* driver adds RUN nibble */
}

/* rasteriser calls this */
void scanline_out(uint8_t y,
        uint16_t x0,uint16_t x1,
        uint8_t u0,uint8_t u1,
        uint8_t v0,uint8_t v1,
        uint8_t z0,uint8_t z1)
{
//	if((x1-x0)<10){
//	xil_printf("y%d  Start:x%d u%d v%d z%d  End:x%d u%d v%d z%d\r",y,x0,u0,v0,z0,x1,u1,v1,z1);
//	}
	push_scanline(y,x0,x1,u0,u1,v0,v1,z0,z1);
    //stats_scanline_sent();
}

void gpu_line_test(){
	uint8_t y = 70;
	uint16_t x0 = 73;uint16_t x1 = 160;
	uint8_t u0 = 0; uint8_t u1 = 15;
	uint8_t v0 = 0; uint8_t v1 = 15;
	uint8_t z0 = 16; uint8_t z1 = 16;
	push_scanline(y,x0,x1,u0,u1,v0,v1,z0,z1);
}

/* ---------- Quaternion operations ---------- */
typedef struct { float w, x, y, z; } quat;

// ������Ԫ��
static inline quat quat_create(float w, float x, float y, float z) {
    quat q = {w, x, y, z};
    return q;
}

// ��Ԫ����һ��
static inline quat quat_normalize(quat q) {
    float len = sqrtf(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    if (len > 0.0001f) {
        q.w /= len;
        q.x /= len;
        q.y /= len;
        q.z /= len;
    }
    return q;
}

// ��Ԫ���˷�
static inline quat quat_mul(quat a, quat b) {
    quat q;
    q.w = a.w*b.w - a.x*b.x - a.y*b.y - a.z*b.z;
    q.x = a.w*b.x + a.x*b.w + a.y*b.z - a.z*b.y;
    q.y = a.w*b.y - a.x*b.z + a.y*b.w + a.z*b.x;
    q.z = a.w*b.z + a.x*b.y - a.y*b.x + a.z*b.w;
    return q;
}

// ��ŷ���Ǵ�����Ԫ�� (��ZYX˳��)
static quat quat_from_euler(float rx, float ry, float rz) {
    float cx = cosf(rx/2), sx = sinf(rx/2);
    float cy = cosf(ry/2), sy = sinf(ry/2);
    float cz = cosf(rz/2), sz = sinf(rz/2);
    
    quat q;
    q.w = cx*cy*cz + sx*sy*sz;
    q.x = sx*cy*cz - cx*sy*sz;
    q.y = cx*sy*cz + sx*cy*sz;
    q.z = cx*cy*sz - sx*sy*cz;
    
    return quat_normalize(q);
}

// ��Ԫ��ת��Ϊ��ת����
static mat3 quat_to_mat3(quat q) {
    mat3 R;
    float xx = q.x*q.x, xy = q.x*q.y, xz = q.x*q.z, xw = q.x*q.w;
    float yy = q.y*q.y, yz = q.y*q.z, yw = q.y*q.w;
    float zz = q.z*q.z, zw = q.z*q.w;
    
    R.m[0][0] = 1 - 2*(yy + zz);
    R.m[0][1] = 2*(xy - zw);
    R.m[0][2] = 2*(xz + yw);
    
    R.m[1][0] = 2*(xy + zw);
    R.m[1][1] = 1 - 2*(xx + zz);
    R.m[1][2] = 2*(yz - xw);
    
    R.m[2][0] = 2*(xz - yw);
    R.m[2][1] = 2*(yz + xw);
    R.m[2][2] = 1 - 2*(xx + yy);
    
    return R;
}

int main(void)
{
    init_platform();

    //gpu_init();

    xil_printf("Initializing MAX3421E and USB...\r\n");
    MAX3421E_init();
    USB_init();
    //stats_init(&Usb_timer);
    /* rotation state */
    float rx = 0.f, ry = 0.f, rz = 0.f;
    quat current_rotation = quat_create(1.0f, 0.0f, 0.0f, 0.0f); // ��ʼ��Ϊ��λ��Ԫ��

    /* USB HID bookkeeping */
    BYTE running = 0;
    BYTE device  = 0;
    BOOT_KBD_REPORT kbdbuf;
    BYTE rcode;

    while (1) {
        /* mandatory low level tasks */
        MAX3421E_Task();
        USB_Task();

        if (GetUsbTaskState() != USB_STATE_RUNNING) {
            running = 0;  /* wait for enumeration to finish      */
            continue;
        }

        if (!running) {
            running = 1;
            device  = 1;
            xil_printf("USB device ready. Class = %d\r", device);
            continue;
        }

        /* ---------- keyboard polling ---------- */
        if (device == 1) {                 /* 1 = HID keyboard       */
            rcode = kbdPoll(&kbdbuf);
            if (rcode == hrNAK)  goto ROTATE_PRINT;  /* no new data  */
            if (rcode) {
                xil_printf("kbdPoll error: 0x%02X\r\n", rcode);
                goto ROTATE_PRINT;
            }
            
            // ����ɵ���תֵ
            float old_rx = rx, old_ry = ry, old_rz = rz;
            
            // ��ȡ�µİ�������
            handle_usb_keyboard(&kbdbuf, &rx, &ry, &rz);
            
            // ֻ�����а�������ʱ�Ÿ�����ת
            if (rx != old_rx || ry != old_ry || rz != old_rz) {
                // ����������ת
                float delta_rx = rx - old_rx;
                float delta_ry = ry - old_ry;
                float delta_rz = rz - old_rz;
                
                // ����������ת��Ԫ��
                quat delta_rotation = quat_from_euler(delta_rx, delta_ry, delta_rz);
                // ���µ�ǰ��ת
                current_rotation = quat_mul(delta_rotation, current_rotation);
                current_rotation = quat_normalize(current_rotation);
            }
        }

ROTATE_PRINT:
        /* ---------- rotate cube & print verts -- */
        mat3 R = quat_to_mat3(current_rotation);

        for (int i = 0; i < 8; ++i) { //<---------------------------------8
            g_world[i] = mat3_mul_vec3(R, g_model[i]);

            int sx = (int)((g_world[i].x + 1.f) * 119.5f+40);
            int sy = (int)((g_world[i].y + 1.f) * 119.5f);
            screen_pts[i] = (ivec2){sx, sy};
            depth[i]      = (uint8_t)((g_world[i].z + 1.f) * 63.5f);
        }
        //print_vertices();     /* one compact line per frame       */

        //gpu_line_test();
        for (int t = 0; t < 12; ++t)//<-------------------------------12
            rasterise_triangle(t);

        gpu_frame_done();     /* pulse data[61] */
        //stats_frame_done();
    }

    /* never reached */
    cleanup_platform();
    return 0;
}
