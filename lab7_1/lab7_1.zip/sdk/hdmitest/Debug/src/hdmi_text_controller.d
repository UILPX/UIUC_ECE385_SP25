src/hdmi_text_controller.o src/hdmi_text_controller.o: \
 ../src/hdmi_text_controller.c ../src/hdmi_text_controller.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xstatus.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_assert.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/sleep.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_io.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_printf.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/bspconfig.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xstatus.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/mb_interface.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_exception.h
../src/hdmi_text_controller.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xstatus.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_assert.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/sleep.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_io.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_printf.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/bspconfig.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xstatus.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/mb_interface.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_exception.h:
