src/platform.o src/platform.o: ../src/platform.c \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_cache.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/mb_interface.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_assert.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_exception.h \
 D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h \
 ../src/platform_config.h
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_cache.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/mb_interface.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_types.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_assert.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xil_exception.h:
D:/School/UIUC_ECE385_SP25/lab7_1/sdk/mb_lab7_1_wrapper/export/mb_lab7_1_wrapper/sw/mb_lab7_1_wrapper/standalone_microblaze_0/bspinclude/include/xparameters.h:
../src/platform_config.h:
